import os, csv, json, base64, time
from pathlib import Path
from PIL import Image

from heuristic_pipeline import process_claim

INPUT_CSV = 'dataset/claims.csv'
OUTPUT_CSV = 'output.csv'

def main():
    with open(INPUT_CSV, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    output_rows = []
    for row in rows:
        res = process_claim(row)
        output_rows.append(res)
    with open(OUTPUT_CSV, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=output_rows[0].keys())
        writer.writeheader()
        writer.writerows(output_rows)
    print(f"Wrote {len(output_rows)} rows to {OUTPUT_CSV}")

if __name__ == '__main__':
    main()
